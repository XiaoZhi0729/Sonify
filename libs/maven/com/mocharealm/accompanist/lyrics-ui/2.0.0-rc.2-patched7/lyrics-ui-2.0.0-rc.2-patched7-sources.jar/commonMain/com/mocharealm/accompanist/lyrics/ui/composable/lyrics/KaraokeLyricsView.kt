package com.mocharealm.accompanist.lyrics.ui.composable.lyrics

import com.mocharealm.accompanist.lyrics.ui.internal.layout.lyricsAutoScroll
import com.mocharealm.accompanist.lyrics.ui.internal.layout.settledHeight
import com.mocharealm.accompanist.lyrics.ui.internal.rendering.PreparedLineText
import com.mocharealm.accompanist.lyrics.ui.internal.rendering.LyricsTexturePrefetch
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.draw.clipToBounds
import com.mocharealm.accompanist.lyrics.ui.internal.effects.lyricsEdgeFade
import com.mocharealm.accompanist.lyrics.ui.internal.effects.LyricsCaptionTransitions
import com.mocharealm.accompanist.lyrics.ui.internal.effects.LocalLyricsCaptionTransitions
import kotlinx.coroutines.flow.first
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextMotion
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mocharealm.accompanist.lyrics.core.model.ISyncedLine
import com.mocharealm.accompanist.lyrics.core.model.SyncedLyrics
import com.mocharealm.accompanist.lyrics.core.model.karaoke.KaraokeAlignment
import com.mocharealm.accompanist.lyrics.core.model.karaoke.KaraokeLine
import com.mocharealm.accompanist.lyrics.core.model.synced.SyncedLine
import com.mocharealm.accompanist.lyrics.ui.composable.list.*
import com.mocharealm.accompanist.lyrics.ui.internal.layout.LyricsLazyColumn
import com.mocharealm.accompanist.lyrics.ui.internal.scene.rememberLyricsScene
import com.mocharealm.accompanist.lyrics.ui.preparation.PreparedLyrics
import com.mocharealm.accompanist.lyrics.ui.profile.DefaultLyricsProfiles
import com.mocharealm.accompanist.lyrics.ui.profile.LyricsProfile
import com.mocharealm.accompanist.lyrics.ui.internal.scene.LyricsLayoutRequest
import com.mocharealm.accompanist.lyrics.ui.internal.text.isRtl

/**
 * Prepares a complete scene when content, profiles, typography or available width changes. Playback
 * writes only to the timeline and active row clocks; lazy items never measure karaoke text. Custom
 * profiles precede the defaults (first match wins).
 *
 * @param currentPosition Playback position in milliseconds. The provider must read Compose state
 * that changes with playback; plain player getters do not notify the timeline or request redraws.
 */
@Composable
fun KaraokeLyricsView(
    listState: LyricsLazyListState,
    lyrics: SyncedLyrics,
    currentPosition: () -> Int,
    onLineClicked: (ISyncedLine) -> Unit,
    onLinePressed: (ISyncedLine) -> Unit,
    modifier: Modifier = Modifier,
    normalLineTextStyle: TextStyle =
        LocalTextStyle.current.copy(
            fontSize = 34.sp,
            lineHeight = TextUnit.Unspecified,
            fontWeight = FontWeight.Bold,
            textMotion = TextMotion.Animated,
        ),
    translationTextStyle: TextStyle =
        LocalTextStyle.current.copy(
            fontSize = 18.sp,
            lineHeight = TextUnit.Unspecified,
            fontWeight = FontWeight.Bold,
            textMotion = TextMotion.Animated,
        ),
    accompanimentLineTextStyle: TextStyle =
        LocalTextStyle.current.copy(
            fontSize = 22.sp,
            lineHeight = TextUnit.Unspecified,
            fontWeight = FontWeight.Bold,
            textMotion = TextMotion.Animated,
        ),
    textColor: Color = Color.White,
    breathingDotsDefaults: KaraokeBreathingDotsDefaults = KaraokeBreathingDotsDefaults(),
    phoneticTextStyle: TextStyle =
        normalLineTextStyle.copy(
            fontSize = 18.sp,
            lineHeight = TextUnit.Unspecified,
            fontWeight = FontWeight.SemiBold,
            textMotion = TextMotion.Static,
        ),
    blendMode: BlendMode = BlendMode.Plus,
    useBlurEffect: Boolean = true,
    showTranslation: Boolean = true,
    showPhonetic: Boolean = true,
    anchor: LyricsAnchor = LyricsAnchor.Fixed(64.dp),
    topFade: LyricsFade = LyricsFade.ToAnchor(16.dp),
    bottomFade: LyricsFade = LyricsFade.Fraction(0.5f),
    keepAliveZone: Dp = 100.dp,
    blurDelta: Float = 3f,
    showDebugRectangles: Boolean = false,
    renderProfiles: List<LyricsProfile> = DefaultLyricsProfiles,
    itemSpacing: Dp = 16.dp,
    scrollAnimationSpec: AnimationSpec<Float> = tween(650, easing = FastOutSlowInEasing),
    autoScrollResumeDelayMillis: Long = 2500,
    scrollChain: LyricsScrollChain? = LyricsScrollChain(),
    /** 外部缓存好的排版结果：给定后不再重新测量文本（页面切换时不重排）。 */
    preparedLyrics: PreparedLyrics? = null,
    /** 场景缓存键：相同键重新进入时复用整个场景（含渲染资源与栅格）。 */
    sceneCacheKey: Any? = null,
) {
    val currentProvider by rememberUpdatedState(currentPosition)
    val timeProvider = remember { { currentProvider() } }
    val measurer = rememberTextMeasurer(cacheSize = 0)
    val density = LocalDensity.current
    val direction = LocalLayoutDirection.current
    val profiles =
        remember(renderProfiles) {
            renderProfiles + DefaultLyricsProfiles.filter { it !in renderProfiles }
        }
    BoxWithConstraints(modifier.clipToBounds()) {
        val anchorOffset = when (anchor) {
            is LyricsAnchor.Fixed -> anchor.offset.coerceAtMost(maxHeight)
            is LyricsAnchor.Fraction -> maxHeight * anchor.fraction
        }
        val width = with(density) { (maxWidth - 32.dp).toPx() }.coerceAtLeast(1f)
        val scene = rememberLyricsScene(
            LyricsLayoutRequest(
                lyrics, profiles, measurer, normalLineTextStyle, accompanimentLineTextStyle,
                phoneticTextStyle, width, density, direction, translationTextStyle,
            ),
            textColor,
            timeProvider,
            preparedLyrics,
            sceneCacheKey,
        ) ?: return@BoxWithConstraints
        val timeline = scene.timeline
        // A single main-vocal row, excluding phonetics, translation and nested vocals.
        // Reuse prepared metrics so font size, line height and font scale stay consistent.
        val breathingLineHeight = remember(scene.lyrics, density) {
            val height = scene.lyrics.lines.asSequence()
                .filterNotNull()
                .filter { it.source is KaraokeLine.MainKaraokeLine }
                .flatMap { it.rows.asSequence() }
                .map { it.height - it.phoneticHeight }
                .maxOrNull()
            if (height == null) 40.dp else with(density) { height.toDp() }
        }
        val captionTransitions = remember(timeline, listState) { LyricsCaptionTransitions() }
        LaunchedEffect(timeline, listState, showTranslation, showPhonetic) {
            // Subcomposed captions start their transitions during the next measure.
            withFrameNanos { }
            snapshotFlow { captionTransitions.idle }.first { it }
            listState.finishCaptionContentChange()
        }
        val previousCaptions =
            remember(timeline, listState) { booleanArrayOf(showTranslation, showPhonetic) }
        SideEffect {
            if (previousCaptions[0] != showTranslation || previousCaptions[1] != showPhonetic) {
                listState.preserveFollowAnchorForContentChange()
                previousCaptions[0] = showTranslation
                previousCaptions[1] = showPhonetic
            }
        }
        val focus by timeline.focus
        val mapping = scene.items
        val sourceIndices = mapping.sourceIndices
        val translationShown = rememberUpdatedState(showTranslation)
        LyricsTexturePrefetch(
            mapping.lines,
            scene.resources,
            listState,
        ) {
            mapping.itemIndex(timeline.focus.value.firstIndex)
        }
        val phoneticShown = rememberUpdatedState(showPhonetic)
        SideEffect { listState.setInterludeItem(focus.activeInterludeIndex?.let(mapping::itemIndex) ?: -1) }
        val listItems =
            remember(scene.lyrics, timeline, mapping) {
                sourceIndices.map { index ->
                    val line = scene.lyrics.lines[index]
                    LyricsListItem(
                        key = "${lyrics.lines[index].start}-${lyrics.lines[index].end}-$index",
                        preserveAnchorOnHeightChange = false,
                        settledHeightPx =
                            line?.let { prepared ->
                                {
                                    prepared
                                        .settledHeight(
                                            timeline.state,
                                            translationShown.value,
                                            phoneticShown.value,
                                            density.density,
                                            index in timeline.focus.value.allIndices,
                                        )
                                        .toInt()
                                }
                            },
                        // Follow the aggregate's top, including any leading accompaniment.
                        // Offsetting by `before` would scroll those vocals above the anchor.
                        estimatedHeightPx =
                            ((line?.height ?: 0f) +
                                    (if (line?.translation != null || line?.phonetic != null)
                                        8f * density.density
                                    else 0f) +
                                    (line?.translation?.size?.height ?: 0) +
                                    (line?.phonetic?.size?.height ?: 0))
                                .toInt(),
                    )
                }
            }
        val followModifier =
            lyricsAutoScroll(
                listState,
                targetIndex = {
                    mapping.itemIndex(timeline.focus.value.firstIndex)
                },
                animationSpec = scrollAnimationSpec,
                resumeDelayMillis = autoScrollResumeDelayMillis,
                focusEndIndex = {
                    mapping.itemIndex(
                        timeline.focus.value.allIndices.lastOrNull()
                            ?: timeline.focus.value.firstIndex
                    )
                },
                playbackPosition = timeProvider,
            )
        // One shared animation, sampled only by graphics layers; no per-frame item recomposition.
        val focusBlurFactor =
            animateFloatAsState(
                targetValue = if (listState.isManualScrolling) 0f else 1f,
                animationSpec = tween(if (listState.isManualScrolling) 100 else 300),
                label = "manualScrollFocusBlur",
            )
        CompositionLocalProvider(LocalLyricsCaptionTransitions provides captionTransitions) {
            LyricsLazyColumn(
                items = listItems,
                state = listState,
                itemSpacing = itemSpacing,
                scrollChain = scrollChain,
                beyondBounds = keepAliveZone,
                contentPadding = PaddingValues(top = anchorOffset, bottom = maxHeight + keepAliveZone),
                modifier =
                    Modifier.fillMaxSize()
                        .then(followModifier)
                        .graphicsLayer {
                            compositingStrategy = CompositingStrategy.Offscreen
                            this.blendMode = blendMode
                        }
                        .lyricsEdgeFade(topFade, bottomFade, anchorOffset),
            ) { itemIndex ->
                val index = sourceIndices[itemIndex]
                val line = lyrics.lines[index]
                val prepared = scene.lyrics.lines[index]
                val focused = index in focus.allIndices
                val distance =
                    maxOf(
                        0,
                        (focus.allIndices.firstOrNull() ?: focus.firstIndex) - index,
                        index - (focus.allIndices.lastOrNull() ?: focus.firstIndex),
                    )
                val blur by
                animateFloatAsState(if (useBlurEffect) distance * blurDelta else 0f, tween(300))
                Column {
                    if (index == 0 && focus.activeIntro)
                        KaraokeBreathingDots(
                            alignment =
                                if (prepared?.rightAligned == true)
                                    KaraokeAlignment
                                        .End
                                else
                                    KaraokeAlignment
                                        .Start,
                            startTimeMs = 0,
                            endTimeMs = timeline.introEnd,
                            currentTimeProvider = timeProvider,
                            defaults = breathingDotsDefaults,
                            trailingSpacing = itemSpacing,
                            lineHeight = breathingLineHeight,
                        )
                    if (focus.activeInterludeIndex == index && index > 0)
                        KaraokeBreathingDots(
                            alignment =
                                if (prepared?.rightAligned == true)
                                    KaraokeAlignment
                                        .End
                                else
                                    KaraokeAlignment
                                        .Start,
                            startTimeMs = timeline.interludeStarts[index],
                            endTimeMs = timeline.interludeEnds[index],
                            currentTimeProvider = timeProvider,
                            defaults = breathingDotsDefaults,
                            trailingSpacing = itemSpacing,
                            lineHeight = breathingLineHeight,
                        )
                    if (prepared !in scene.lyrics.embeddedLines)
                        LyricsLineItem(
                            isFocused = focused,
                            isRightAligned =
                                prepared?.rightAligned
                                    ?: ((line as? SyncedLine)?.content?.isRtl() == true),
                            onLineClicked = {
                                listState.resumeAutoScroll(line.start, itemIndex)
                                onLineClicked(line)
                            },
                            onLinePressed = { onLinePressed(line) },
                            interactiveWidthPx = prepared?.width,
                            interactiveRows = prepared?.let { p ->
                                val pad =
                                    if (p.source is KaraokeLine.AccompanimentKaraokeLine) 0f
                                    else 16f * density.density
                                // 整句一个点击层：宽度取最宽的一折、高度覆盖所有折行，
                                // 这样折行歌词的涟漪覆盖整句，而不是只亮被点中的那一行。
                                val maxRowWidth = p.rows.maxOfOrNull { it.width } ?: 0f
                                val top = p.rows.firstOrNull()?.top ?: 0f
                                val bottom =
                                    p.rows.lastOrNull()?.let { it.top + it.height } ?: top
                                val baseLeft =
                                    if (p.rightAligned) width - pad - maxRowWidth else pad
                                // 涟漪不要贴着文字：左右各外扩 8dp、上下各 4dp
                                val expandX = 8f * density.density
                                val expandY = 4f * density.density
                                listOf(
                                    Rect(
                                        left = (baseLeft - expandX).coerceAtLeast(0f),
                                        top = (top - expandY).coerceAtLeast(0f),
                                        right = (baseLeft + maxRowWidth + expandX)
                                            .coerceAtMost(width),
                                        bottom = bottom + expandY,
                                    )
                                )
                            },
                            blurRadius = { blur * focusBlurFactor.value },
                        ) {
                            if (prepared != null)
                                PreparedLineText(
                                    prepared,
                                    timeline.state,
                                    scene.resources,
                                    currentTimeProvider = timeProvider,
                                    verticalPadding = 0.dp,
                                    modifier =
                                        if (line is KaraokeLine.AccompanimentKaraokeLine)
                                            Modifier.padding(horizontal = 16.dp)
                                        else Modifier,
                                    showTranslation = showTranslation,
                                    showPhonetic = showPhonetic,
                                    showDebugRectangles = showDebugRectangles,
                                )
                        }
                }
            }
        }
    }
}
