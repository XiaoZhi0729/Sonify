package com.mocharealm.accompanist.lyrics.ui.internal.scene

import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import com.mocharealm.accompanist.lyrics.ui.preparation.PreparedLyrics
import com.mocharealm.accompanist.lyrics.ui.internal.rendering.LyricsRenderResources
import com.mocharealm.accompanist.lyrics.ui.internal.scene.LyricsLayoutRequest
import com.mocharealm.accompanist.lyrics.ui.internal.scene.LyricsScene
import com.mocharealm.accompanist.lyrics.ui.internal.scene.LyricsSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/** 场景缓存：页面被销毁后重新进入时复用整个场景（排版/时间轴/渲染资源/栅格）。 */
internal object LyricsSceneCache {
    private const val MAX_ENTRIES = 2
    private val scenes =
        object : LinkedHashMap<Any, LyricsScene>(4, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Any, LyricsScene>?) =
                size > MAX_ENTRIES
        }

    fun get(key: Any): LyricsScene? = scenes[key]
    fun put(key: Any, value: LyricsScene) { scenes[key] = value }
}

/** Shared lifecycle for full lyrics and standalone lines; no preparation happens in composition. */
@Composable
internal fun rememberLyricsScene(
    request: LyricsLayoutRequest,
    color: Color,
    currentPosition: () -> Int,
    preparedLyrics: PreparedLyrics? = null,
    sceneCacheKey: Any? = null,
): LyricsScene? {
    val position by rememberUpdatedState(currentPosition)
    // 命中缓存：直接复用上次构建好的场景（含栅格），只把时间轴对齐到当前播放位置。
    val cached = remember(sceneCacheKey) {
        sceneCacheKey?.let(LyricsSceneCache::get)
    }
    if (cached != null) {
        LaunchedEffect(cached) {
            snapshotFlow { position() }.collect { cached.timeline.update(it) }
        }
        return cached
    }
    val layoutState = remember(request, preparedLyrics) { mutableStateOf<LyricsSession?>(null) }
    LaunchedEffect(layoutState) {
        while (isActive) {
            val session = withContext(Dispatchers.Default) {
                LyricsSession(request.lyrics, preparedLyrics ?: request.prepare())
            }
            layoutState.value = session
            // External geometry is caller-owned, including its font invalidation policy.
            if (preparedLyrics != null) return@LaunchedEffect
            snapshotFlow { session.lyrics.hasStaleFonts() }.first { it }
        }
    }
    val session = layoutState.value ?: return null
    val prepared = session.lyrics
    val timeline = session.timeline
    val items = session.items
    LaunchedEffect(timeline) {
        snapshotFlow { position() }.collect { timeline.update(it) }
    }
    val sceneState = remember(prepared, timeline) {
        mutableStateOf<LyricsScene?>(null)
    }
    // Keep the complete previous color variant attached while its replacement is prepared.
    LaunchedEffect(sceneState, color, request.density, request.direction) {
        val resources = withContext(Dispatchers.Default) {
            LyricsRenderResources(prepared, color, request.density, request.direction)
        }
        timeline.update(position())
        val built = LyricsScene(prepared, timeline, resources, items)
        sceneState.value = built
        sceneCacheKey?.let { LyricsSceneCache.put(it, built) }
    }
    return sceneState.value
}
