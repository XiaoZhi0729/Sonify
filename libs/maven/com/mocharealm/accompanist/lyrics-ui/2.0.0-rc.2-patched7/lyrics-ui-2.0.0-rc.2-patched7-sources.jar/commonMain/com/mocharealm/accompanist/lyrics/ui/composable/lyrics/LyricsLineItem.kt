package com.mocharealm.accompanist.lyrics.ui.composable.lyrics

import com.mocharealm.accompanist.lyrics.ui.internal.effects.lyricsVisualLayer

import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.spring

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.mocharealm.gaze.capsule.ContinuousRoundedRectangle
import kotlin.math.roundToInt

private val FocusBlurEffects =
    Array<RenderEffect?>(65) { index ->
        if (index == 0) null else BlurEffect(index.toFloat(), index.toFloat(), TileMode.Clamp)
    }

@Composable
fun LyricsLineItem(
    isFocused: Boolean,
    isRightAligned: Boolean,
    onLineClicked: () -> Unit,
    onLinePressed: () -> Unit,
    blurRadius: () -> Float,
    modifier: Modifier = Modifier,
    activeAlpha: Float = 1f,
    inactiveAlpha: Float = 0.4f,
    blendMode: BlendMode = BlendMode.SrcOver,
    isInteractive: Boolean = true,
    /** 文字实际宽度（px）。给定时点击层只覆盖文字，空白处不消费点击。 */
    interactiveWidthPx: Float? = null,
    /** 逐视觉行的点击矩形（px，相对行内容左上角）。给定时按行生成点击层。 */
    interactiveRows: List<Rect>? = null,
    content: @Composable () -> Unit,
) {
    val scaleState by
        animateFloatAsState(
            targetValue = if (isFocused) 1f else 0.98f,
            animationSpec =
                if (isFocused) {
                    tween(durationMillis = 600, easing = LinearOutSlowInEasing)
                } else {
                    tween(durationMillis = 300, easing = EaseInOut)
                },
            label = "scale",
        )

    val alphaState by
        animateFloatAsState(
            targetValue = if (isFocused) activeAlpha else inactiveAlpha,
            label = "alpha",
        )

    Box(
        modifier =
            modifier.fillMaxWidth().lyricsVisualLayer(observePaint = {
                alphaState
                blurRadius()
            }) {
                scaleX = scaleState
                scaleY = scaleState
                alpha = alphaState
                transformOrigin = TransformOrigin(if (isRightAligned) 1f else 0f, 1f)
                this.blendMode = blendMode
                compositingStrategy = CompositingStrategy.Auto

                val radius =
                    blurRadius()
                        .takeIf { it.isFinite() }
                        ?: 0f
                renderEffect = FocusBlurEffects[radius.roundToInt().coerceIn(0, 64)]
            },
        contentAlignment =
            if (isRightAligned) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        // 点击层只覆盖文字实际宽度：宽度受限的内层 Box 包住内容，点击层再 matchParentSize。
        // 宽度为空（间奏行等）时退回整行。
        val rows = interactiveRows
        if (isInteractive && rows != null && rows.isNotEmpty()) {
            // 整句点击层：矩形由调用方按文字宽度给出（可外扩），涟漪覆盖整句。
            val density = LocalDensity.current
            val interactionSource = remember { MutableInteractionSource() }
            val pressed by interactionSource.collectIsPressedAsState()
            val pressedScale by
                animateFloatAsState(
                    targetValue = if (pressed) 0.97f else 1f,
                    animationSpec = spring(stiffness = 700f, dampingRatio = 0.75f),
                    label = "linePressedScale",
                )
            Box(Modifier.fillMaxWidth()) {
                rows.forEach { r ->
                    Box(
                        Modifier
                            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                            .size(
                                width = with(density) { r.width.toDp() },
                                height = with(density) { r.height.toDp() },
                            )
                            .clip(ContinuousRoundedRectangle(8.dp))
                            .combinedClickable(
                                interactionSource = interactionSource,
                                indication = LocalIndication.current,
                                onClick = onLineClicked,
                                onLongClick = onLinePressed,
                            )
                    )
                }
                Box(
                    Modifier.graphicsLayer {
                        scaleX = pressedScale
                        scaleY = pressedScale
                        transformOrigin = TransformOrigin(0.5f, 0.5f)
                    }
                ) {
                    content()
                }
            }
        } else {
            Box(
                modifier =
                    if (interactiveWidthPx != null && interactiveWidthPx > 0f) {
                        Modifier.width(with(LocalDensity.current) { interactiveWidthPx.toDp() })
                    } else {
                        Modifier.fillMaxWidth()
                    }
            ) {
                // Clip the ripple, never the lyrics that can draw beyond their animated layout height.
                if (isInteractive)
                    Box(
                        Modifier.matchParentSize()
                            .clip(ContinuousRoundedRectangle(8.dp))
                            .combinedClickable(onClick = onLineClicked, onLongClick = onLinePressed)
                    )
                content()
            }
        }
    }
}
